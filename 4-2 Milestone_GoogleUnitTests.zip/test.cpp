// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    // is the collection still empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, what must the size be?
    ASSERT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // get the current size of the collection
    size_t current_size = collection->size();

    add_entries(5);

    // is the collection empty?
    ASSERT_FALSE(collection->empty());

    // calcuate the expected size of the collection after adding five values
    size_t expected_size = current_size + 5;   
    ASSERT_EQ(collection->size(), expected_size);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, VerifyVectorMaxSize) 
{   
    //verify max size is greater than 0 entries
    ASSERT_EQ(collection->size(), 0);
    ASSERT_GE(collection->max_size(), collection->size());

    // verify max size is greater than 1 entry
    add_entries(1);
    ASSERT_EQ(collection->size(), 1);
    ASSERT_GE(collection->max_size(), collection->size());

    // verify max size is greater than 5 entries
    add_entries(4);
    ASSERT_EQ(collection->size(), 5);
    ASSERT_GE(collection->max_size(), collection->size());

    // verify max size is greater than 10 entries
    add_entries(5);
    ASSERT_EQ(collection->size(), 10);
    ASSERT_GE(collection->max_size(), collection->size());
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, VerifyVectorCapacity)
{
    // verify capacity is greater than 0 entries
    ASSERT_EQ(collection->size(), 0);
    ASSERT_GE(collection->capacity(), collection->size());

    // verify capacity is greater than 1 entry
    add_entries(1);
    ASSERT_EQ(collection->size(), 1);
    ASSERT_GE(collection->capacity(), collection->size());

    // verify capacity is greater than 5 entries
    add_entries(4);
    ASSERT_EQ(collection->size(), 5);
    ASSERT_GE(collection->capacity(), collection->size());

    // verify capacity is greater than 10 entries
    add_entries(5);
    ASSERT_EQ(collection->size(), 10);
    ASSERT_GE(collection->capacity(), collection->size());
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, CanResizeToIncreaseVector) 
{
    // add 10 entries to the collection
    add_entries(10);
    EXPECT_EQ(collection->size(), 10);

    // resize collection to have 20 entries
    collection->resize(20);
    ASSERT_TRUE(collection->size() > 10);
    ASSERT_EQ(collection->size(), 20);
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, CanResizeToDecreaseVector)
{
    // add 10 entries to the collection
    add_entries(10);
    EXPECT_EQ(collection->size(), 10);

    // resize collection to have 5 entries
    collection->resize(5);
    ASSERT_TRUE(collection->size() < 10);
    ASSERT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, CanResizeToDecreaseToZero)
{
    // add 10 entries to the collection
    add_entries(10);
    EXPECT_EQ(collection->size(), 10);

    // resize collection to have 0 entries
    collection->resize(0);
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, VerifyClearFunctionReturnsEmptyCollection)
{
    // add data to get a non-empty collection
    add_entries(10);
    EXPECT_EQ(collection->size(), 10);

    // clear the collection
    collection->clear();

    ASSERT_TRUE(collection->empty());
    // if collection is empty then size must be 0
    ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, VerifyEraseFunctionReturnsEmptyCollection)
{
    // add data to get a non-empty collection
    add_entries(10);
    EXPECT_EQ(collection->size(), 10);

    // clear the collection using the erase function
    collection->erase(collection->begin(), collection->end());

    ASSERT_TRUE(collection->empty());
    // if collection is empty then size must be 0
    ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, CanReserveToIncreaseCapacity)
{
    add_entries(5);

    // validate collection size
    EXPECT_EQ(collection->size(), 5);

    // record collection capacity and size
    size_t current_capacity = collection->capacity();
    size_t current_size = collection->size();
    
    size_t max_elements = 32;
    
    // validate that max elements to be added is greater than the current capacity
    EXPECT_GT(max_elements, current_capacity);

    // reserve to increase capacity with max elements
    collection->reserve(max_elements);

    // verify new capacity is greater than current_capacity
    ASSERT_GT(collection->capacity(), current_capacity);

    // verify size of the collection is the same as current_size
    ASSERT_EQ(collection->size(), current_size);
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, CanThrowIndexOutOfBoundsException)
{
    // add 3 entries
    add_entries(3);

    // verify the std::out_of_range exception is thrown when calling at() with index 5 (out of bounds)
    EXPECT_THROW(collection->at(5), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative

// A negative test to verify the std::out_of_range expception is thrown when calling at() with index equal to the size()
TEST_F(CollectionTest, CanThrowUpperBoundException)
{
    // add 3 entries
    add_entries(3);

    // set index equal to the current size
    auto it = collection->size();

    // verify std::out_of_range exception is thrown
    EXPECT_THROW(collection->at(it), std::out_of_range);
}

// A test to verify that calling pop_back() decrements collection size and erases the last entry but does not change the capacity
TEST_F(CollectionTest, CanRemoveTheLastEntry)
{
    add_entries(5);

    // get second to last element
    int second_to_last = collection->at(collection->size() - 2);

    // get the current size
    size_t last_size = collection->size();

    // get the current capacity
    size_t last_capacity = collection->capacity();

    // remove the last element
    collection->pop_back();

    // verify second to last element is the current last element
    ASSERT_EQ(collection->back(), second_to_last);
    // size should be decremented by one
    ASSERT_LT(collection->size(), last_size);
    ASSERT_EQ(collection->size(), last_size - 1);
    // verify that the capacity has not changed
    ASSERT_EQ(last_capacity, collection->capacity());
}



