// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <stdexcept>

class CustomException : public std::exception {

private:
    std::string message;

public:
    // constructor
    explicit CustomException(const std::string& msg) : message(msg) {}

    // override of what() method
    const char* what() const noexcept override {
        return message.c_str();
    }
};

bool do_even_more_custom_application_logic()
{
    // throwing a standard std::out_of_range exception
    throw std::out_of_range("Out of Range Exception occurred");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try {

        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& ex) {
        // exception handler catches std::exception
        // displays message and exception.what()
        std::cerr << "Found exception in Custom Application Logic: " << ex.what() << std::endl;
   }

    // Throw a custom exception
    throw CustomException("My Custom Exception occurred!");

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    
    if (den == 0) {
        // throws std::runtime_error exception is denominator argument is 0
        throw std::runtime_error("Attempted to divide by zero");
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::runtime_error& ex) {
        // catches only std::runtime_error exception thrown by divide()
        std::cerr << ex.what() << std::endl;
    }
    
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& ex) {
        // catches the custom exception
        std::cerr << "Caught exception: " << ex.what() << std::endl;
    }
    catch (const std::exception& ex) {
        // catches a standard exception
        std::cerr << "Caught exception: " << ex.what() << std::endl;
    }
    catch (...) {
        // catches any unknown exceptions
        std::cerr << "Caught unknown exception!" << std::endl;
    }
    
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu